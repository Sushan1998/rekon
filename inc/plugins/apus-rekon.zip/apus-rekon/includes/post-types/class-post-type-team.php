<?php
/**
 * Post Type: Team
 *
 * @package    apus-rekon
 * @author     Habq 
 * @license    GNU General Public License, version 3
 */

if ( ! defined( 'ABSPATH' ) ) {
  	exit;
}

class Apus_Rekon_Post_Type_Team {
	public static function init() {
	  	add_action( 'init', array( __CLASS__, 'register_post_type' ) );
	  	add_filter( 'cmb2_meta_boxes', array( __CLASS__, 'metaboxes' ) );
	}

	public static function register_post_type() {
		$labels = array(
			'name'                  => __( 'Teams', 'apus-rekon' ),
			'singular_name'         => __( 'Team', 'apus-rekon' ),
			'add_new'               => __( 'Add New Team', 'apus-rekon' ),
			'add_new_item'          => __( 'Add New Team', 'apus-rekon' ),
			'edit_item'             => __( 'Edit Team', 'apus-rekon' ),
			'new_item'              => __( 'New Team', 'apus-rekon' ),
			'all_items'             => __( 'All Teams', 'apus-rekon' ),
			'view_item'             => __( 'View Team', 'apus-rekon' ),
			'search_items'          => __( 'Search Team', 'apus-rekon' ),
			'not_found'             => __( 'No Teams found', 'apus-rekon' ),
			'not_found_in_trash'    => __( 'No Teams found in Trash', 'apus-rekon' ),
			'parent_item_colon'     => '',
			'menu_name'             => __( 'Teams', 'apus-rekon' ),
		);
		
		register_post_type( 'team',
			array(
				'labels'            => $labels,
				'supports'          => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt' ),
				'public'            => true,
		        'has_archive'       => true,
				'show_in_rest'		=> true,
				'menu_icon'         => 'dashicons-admin-post',
			)
		);
	}

	/**
	 *
	 */
	public static function metaboxes( array $metaboxes ) {
		$prefix = APUS_REKON_TEAM_PREFIX;
		
		$metaboxes[ $prefix . 'info' ] = array(
			'id'                        => $prefix . 'info',
			'title'                     => __( 'More Information', 'apus-rekon' ),
			'object_types'              => array( 'team' ),
			'context'                   => 'normal',
			'priority'                  => 'high',
			'show_names'                => true,
			'fields'                    => self::metaboxes_info_fields()
		);
		
		$metaboxes[ $prefix . 'socials' ] = array(
			'id'                        => $prefix . 'socials',
			'title'                     => __( 'Socials', 'apus-rekon' ),
			'object_types'              => array( 'team' ),
			'context'                   => 'normal',
			'priority'                  => 'high',
			'show_names'                => true,
			'show_in_rest'				=> true,
			'fields'                    => array(
				array(
					'name'              => __( 'Socials', 'apus-rekon' ),
					'id'                => $prefix . 'socials',
					'type'              => 'group',
					'options'     		=> array(
						'group_title'       => __( 'Network {#}', 'apus-rekon' ),
						'add_button'        => __( 'Add Another Network', 'apus-rekon' ),
						'remove_button'     => __( 'Remove Network', 'apus-rekon' ),
						'sortable'          => false,
						'closed'         => true,
					),
					'fields'			=> array(
						array(
							'name'      => __( 'Network', 'apus-rekon' ),
							'id'        => 'network',
							'type'      => 'select',
							'options'   => array(
								'facebook' => __('Facebook', 'apus-rekond'),
								'twitter' => __('Twitter', 'apus-rekond'),
								'linkedin' => __('Linkedin', 'apus-rekond'),
								'dribbble' => __('Dribbble', 'apus-rekond'),
								'youtube' => __('Youtube', 'apus-rekond'),
								'instagram' => __('Instagram', 'apus-rekond'),
							)
						),
						array(
							'name'      => __( 'Url', 'apus-rekon' ),
							'id'        => 'url',
							'type'      => 'text',
						),
					),
				),
			),
		);

		$metaboxes[ $prefix . 'activities' ] = array(
			'id'                        => $prefix . 'activities',
			'title'                     => __( 'Our Activities', 'apus-rekon' ),
			'object_types'              => array( 'team' ),
			'context'                   => 'normal',
			'priority'                  => 'high',
			'show_names'                => true,
			'show_in_rest'				=> true,
			'fields'                    => array(
				array(
					'name'              => __( 'Activities', 'apus-rekon' ),
					'id'                => $prefix . 'activities',
					'type'              => 'group',
					'options'     		=> array(
						'group_title'       => __( 'Activity {#}', 'apus-rekon' ),
						'add_button'        => __( 'Add Activity', 'apus-rekon' ),
						'remove_button'     => __( 'Remove Activity', 'apus-rekon' ),
						'sortable'          => false,
						'closed'        => true,
					),
					'fields'			=> array(
						array(
							'name'      => __( 'Title', 'apus-rekon' ),
							'id'        => 'title',
							'type'      => 'text',
						),
						array(
							'name'      => __( 'Icon', 'apus-rekon' ),
							'id'        => 'icon',
							'type'      => 'text',
							'desc'		=> __( 'Enter font icon class.', 'apus-rekon' ),
						),
						array(
							'name'      => __( 'Description', 'apus-rekon' ),
							'id'        => 'description',
							'type'      => 'textarea',
						),
					),
				),
			),
		);

		$metaboxes[ $prefix . 'skills' ] = array(
			'id'                        => $prefix . 'skills',
			'title'                     => __( 'Our Skills', 'apus-rekon' ),
			'object_types'              => array( 'team' ),
			'context'                   => 'normal',
			'priority'                  => 'high',
			'show_names'                => true,
			'show_in_rest'				=> true,
			'fields'                    => array(
				array(
					'name'      => __( 'Description', 'apus-rekon' ),
					'id'        => $prefix . 'description',
					'type'      => 'textarea',
				),
				array(
					'name'              => __( 'Skills', 'apus-rekon' ),
					'id'                => $prefix . 'skills',
					'type'              => 'group',
					'options'     		=> array(
						'group_title'       => __( 'Skill {#}', 'apus-rekon' ),
						'add_button'        => __( 'Add Skill', 'apus-rekon' ),
						'remove_button'     => __( 'Remove Skill', 'apus-rekon' ),
						'sortable'          => false,
						'closed'        => true,
					),
					'fields'			=> array(
						array(
							'name'      => __( 'Title', 'apus-rekon' ),
							'id'        => 'title',
							'type'      => 'text',
						),
						array(
							'name'      => __( 'Value', 'apus-rekon' ),
							'id'        => 'value',
							'type'      => 'text',
							'desc'		=> __( 'Enter value', 'apus-rekon' ),
						),
					),
				),
			),
		);

		return $metaboxes;
	}
	/**
	 *
	 */	
	public static function metaboxes_info_fields() {
		$prefix = APUS_REKON_TEAM_PREFIX;

		$fields = array(
			array(
			    'name' => __( 'Job', 'apus-rekon' ),
			    'id' => $prefix.'job',
			    'type' => 'text',
			),
			array(
			    'name' => __( 'Project Icon Class', 'apus-rekon' ),
			    'id' => $prefix.'icon',
			    'type' => 'text',
			)
		);
		
		return apply_filters( 'apus_rekon_postype_team_metaboxes_fields' , $fields, $prefix );
	}
}
Apus_Rekon_Post_Type_Team::init();


