<?php
/**
 * Post Type: Project
 *
 * @package    apus-rekon
 * @author     Habq 
 * @license    GNU General Public License, version 3
 */

if ( ! defined( 'ABSPATH' ) ) {
  	exit;
}

class Apus_Rekon_Post_Type_Project {
	public static function init() {
	  	add_action( 'init', array( __CLASS__, 'register_post_type' ) );
	  	add_filter( 'cmb2_meta_boxes', array( __CLASS__, 'metaboxes' ) );
	}

	public static function register_post_type() {
		$labels = array(
			'name'                  => __( 'Projects', 'apus-rekon' ),
			'singular_name'         => __( 'Project', 'apus-rekon' ),
			'add_new'               => __( 'Add New Project', 'apus-rekon' ),
			'add_new_item'          => __( 'Add New Project', 'apus-rekon' ),
			'edit_item'             => __( 'Edit Project', 'apus-rekon' ),
			'new_item'              => __( 'New Project', 'apus-rekon' ),
			'all_items'             => __( 'All Projects', 'apus-rekon' ),
			'view_item'             => __( 'View Project', 'apus-rekon' ),
			'search_items'          => __( 'Search Project', 'apus-rekon' ),
			'not_found'             => __( 'No Projects found', 'apus-rekon' ),
			'not_found_in_trash'    => __( 'No Projects found in Trash', 'apus-rekon' ),
			'parent_item_colon'     => '',
			'menu_name'             => __( 'Projects', 'apus-rekon' ),
		);
		
		register_post_type( 'project',
			array(
				'labels'            => $labels,
				'supports'          => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt' ),
				'public'            => true,
		        'has_archive'       => true,
				'show_in_rest'		=> true,
				'menu_icon'         => 'dashicons-admin-post',
			)
		);
	}

	/**
	 *
	 */
	public static function metaboxes( array $metaboxes ) {
		$prefix = APUS_REKON_PREFIX;
		
		$metaboxes[ $prefix . 'info' ] = array(
			'id'                        => $prefix . 'info',
			'title'                     => __( 'More Information', 'apus-rekon' ),
			'object_types'              => array( 'project' ),
			'context'                   => 'normal',
			'priority'                  => 'high',
			'show_names'                => true,
			'fields'                    => self::metaboxes_info_fields()
		);
		
		return $metaboxes;
	}
	/**
	 *
	 */	
	public static function metaboxes_info_fields() {
		$prefix = APUS_REKON_PREFIX;

		$fields = array(
			array(
			    'name' => __( 'Icon Class', 'apus-rekon' ),
			    'id' => $prefix.'icon',
			    'type' => 'text',
			),
			array(
			    'name' => __( 'Creative Director', 'apus-rekon' ),
			    'id' => $prefix.'director',
			    'type' => 'text',
			),
			array(
			    'name' => __( 'Date', 'apus-rekon' ),
			    'id' => $prefix.'date',
			    'type' => 'text_date',
			),
			array(
			    'name' => __( 'Client', 'apus-rekon' ),
			    'id' => $prefix.'client',
			    'type' => 'text',
			),
			array(
			    'name' => __( 'Gallery', 'apus-rekon' ),
			    'id' => $prefix.'gallery',
				'type' => 'file_list'
			)
		);
		
		return apply_filters( 'apus_rekon_postype_project_metaboxes_fields' , $fields, $prefix );
	}
}
Apus_Rekon_Post_Type_Project::init();


