<?php
/**
 * Taxonomy: Category
 *
 * @package    apus-rekon
 * @author     Habq 
 * @license    GNU General Public License, version 3
 */
 
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
class Apus_Rekon_Taxonomy_Categories{

	/**
	 *
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'definition' ) );
	}

	/**
	 *
	 */
	public static function definition() {
		$labels = array(
			'name'              => __( 'Categories', 'apus-rekon' ),
			'singular_name'     => __( 'Category', 'apus-rekon' ),
			'search_items'      => __( 'Search Categories', 'apus-rekon' ),
			'all_items'         => __( 'All Categories', 'apus-rekon' ),
			'parent_item'       => __( 'Parent Category', 'apus-rekon' ),
			'parent_item_colon' => __( 'Parent Category:', 'apus-rekon' ),
			'edit_item'         => __( 'Edit', 'apus-rekon' ),
			'update_item'       => __( 'Update', 'apus-rekon' ),
			'add_new_item'      => __( 'Add New', 'apus-rekon' ),
			'new_item_name'     => __( 'New Category', 'apus-rekon' ),
			'menu_name'         => __( 'Categories', 'apus-rekon' ),
		);

		register_taxonomy( 'project_category', 'project', array(
			'labels'            => apply_filters( 'apusrekon_taxomony_category_labels', $labels ),
			'hierarchical'      => true,
			'query_var'         => 'project-category',
			'rewrite'           => array( 'slug' => __( 'project-category', 'apus-rekon' ) ),
			'public'            => true,
			'show_ui'           => true,
			'show_in_rest'		=> true
		) );
	}
}

Apus_Rekon_Taxonomy_Categories::init();