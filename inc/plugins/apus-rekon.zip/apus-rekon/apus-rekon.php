<?php
/**
 * Plugin Name: Apus Rekon
 * Plugin URI: http://apusthemes.com/apus-rekon/
 * Description: Powerful plugin to create a project on your website.
 * Version: 1.0.0
 * Author: Habq
 * Author URI: http://apusthemes.com/
 * Requires at least: 3.8
 * Tested up to: 5.2
 *
 * Text Domain: apus-rekon
 * Domain Path: /languages/
 *
 * @package apus-rekon
 * @category Plugins
 * @author Habq
 */
if ( ! defined( 'ABSPATH' ) ) {
  	exit;
}

if ( !class_exists("Apus_Rekon") ) {
	
	final class Apus_Rekon {

		private static $instance;

		public static function getInstance() {
			if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Apus_Rekon ) ) {
				self::$instance = new Apus_Rekon;
				self::$instance->setup_constants();
				self::$instance->load_textdomain();

				self::$instance->includes();
			}

			return self::$instance;
		}
		/**
		 *
		 */
		public function setup_constants(){
			define( 'APUS_REKON_PLUGIN_VERSION', '1.0.0' );

			define( 'APUS_REKON_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
			define( 'APUS_REKON_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
			define( 'APUS_REKON_PREFIX', 'project_' );
			define( 'APUS_REKON_TEAM_PREFIX', 'team_' );
		}

		public function includes() {
			// post type
			require_once APUS_REKON_PLUGIN_DIR . 'includes/post-types/class-post-type-project.php';
			require_once APUS_REKON_PLUGIN_DIR . 'includes/post-types/class-post-type-team.php';

			require_once APUS_REKON_PLUGIN_DIR . 'includes/taxonomies/class-taxonomy-project-categories.php';

			//
			require_once APUS_REKON_PLUGIN_DIR . 'includes/class-template-loader.php';
			require_once APUS_REKON_PLUGIN_DIR . 'includes/class-mixes.php';
		}

		/**
		 *
		 */
		public function load_textdomain() {
			// Set filter for Apus_Rekon's languages directory
			$lang_dir = APUS_REKON_PLUGIN_DIR . 'languages/';
			$lang_dir = apply_filters( 'apus_rekon_languages_directory', $lang_dir );

			// Traditional WordPress plugin locale filter
			$locale = apply_filters( 'plugin_locale', get_locale(), 'apus-rekon' );
			$mofile = sprintf( '%1$s-%2$s.mo', 'apus-rekon', $locale );

			// Setup paths to current locale file
			$mofile_local  = $lang_dir . $mofile;
			$mofile_global = WP_LANG_DIR . '/apus-rekon/' . $mofile;

			if ( file_exists( $mofile_global ) ) {
				// Look in global /wp-content/languages/apus-rekon folder
				load_textdomain( 'apus-rekon', $mofile_global );
			} elseif ( file_exists( $mofile_local ) ) {
				// Look in local /wp-content/plugins/apus-rekon/languages/ folder
				load_textdomain( 'apus-rekon', $mofile_local );
			} else {
				// Load the default language files
				load_plugin_textdomain( 'apus-rekon', false, $lang_dir );
			}
		}
	}
}

function Apus_Rekon() {
	return Apus_Rekon::getInstance();
}

add_action( 'plugins_loaded', 'Apus_Rekon' );